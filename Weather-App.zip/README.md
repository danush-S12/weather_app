# flutter_weather_app

Flutter weather app with weatherapi.com

Change your API key with the YOUR_API_KEY in constants.dart


