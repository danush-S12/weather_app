import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_weather_app/homepage.dart';

class splash extends StatefulWidget {
  const splash({Key? key}) : super(key: key);

  @override
  State<splash> createState() => _splashState();
}

class _splashState extends State<splash> {
  @override
  void initState() {
    // TODO: implement initState
    Timer(const Duration(seconds: 5), () {
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const HomePage()));
    });
    super.initState();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            Colors.deepPurple,
            Color(0xff0e6ebe),
            Color(0xff4ea1e5),
          ], end: Alignment.bottomLeft, begin: Alignment.topLeft),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Container(
                width: 240,
                height: 240,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        fit: BoxFit.fill,
                        image: NetworkImage(
                            "https://openweathermap.org/img/wn/02d@2x.png"))),
              ),
            ),
            Text(
              "Weather App",
              style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
            )
          ],
        ),
        height: double.infinity,
        width: double.infinity,
      ),
    );
  }
}
